
<?php

//use the following whereever you want to use the data layer
require_once "Products.php";
require_once "Product.php";
