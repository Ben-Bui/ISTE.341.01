<?php
    require_once("lab3_1.php");

    class BritishPerson extends Person {
        
        function calculateBMI(){
            // Convert cm to inches (1 cm = 0.393701 inches)
            $heightInInches = $this->getHeight() * 0.393701;
            
            // Convert kg to pounds (1 kg = 2.20462 lbs)
            $weightInPounds = $this->getWeight() * 2.20462;
            
            return 705 * $weightInPounds / ($heightInInches * $heightInInches);
        }
    }

?>