<?php
class PhoneNumber {
    public $PersonID;
    public $PhoneType;
    public $AreaCode;
    public $PhoneNum;
}
?>