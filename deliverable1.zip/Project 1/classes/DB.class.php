<?php
class DB {
    private $conn;

    function __construct(){
    }

    function getUserByUsername($username) {
    }

    function getAllUsers() {
    }

    function insertUser($username, $password, $roleId, $projectId, $name) {
    }

    function deleteUser($id) {
    }

    function getAllBugs($filters = []) {
    }

    function getBugById($id) {
    }

    function insertBug($bugData) {
    }

    function updateBug($id, $bugData) {
    }

    function getAllProjects() {
    }

    function insertProject($name) {
    }

    function updateProject($id, $name) {
    }

    function getRoles() {
    }

    function getStatuses() {
    }

    function getPriorities() {
    }
}
?>