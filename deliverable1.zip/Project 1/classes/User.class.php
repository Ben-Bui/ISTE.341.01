<?php
class User {
    public function __construct() {
    }

    public function save() {
    }

    public function delete() {
    }

    public static function findById($id) {
    }

    public static function findByUsername($username) {
    }

    public static function getAll() {
    }
}
?>