<html>
<head>
    <title>Question 1</title>
</head>
<body>
<?php
    echo "Hello World"; //print hello world
?>
</body>
</html>
